/** Automatically generated file. DO NOT MODIFY */
package com.rel.relativelayoutform;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}